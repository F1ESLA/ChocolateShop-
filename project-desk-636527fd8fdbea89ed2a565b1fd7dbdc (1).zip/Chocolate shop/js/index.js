// Chenge Header With Scroll
const nav = document.querySelector('.navbar');
const navbarNav = document.querySelector('.navbar-nav');
const shoppingCart = document.querySelector('.nav-bascket');

document.addEventListener('scroll', () => {
  if (window.scrollY >= 410) {
    nav.style.backgroundColor = "black";
    shoppingCart.style.color = "white";
    nav.classList.add('navbar-dark', 'bg-dark');
  }
  else {
    nav.style.backgroundColor = "#f4f4f4";
    shoppingCart.style.color = '';
    nav.classList.remove('navbar-dark', 'bg-dark');
  }
});
// End Chenge Header With Scroll
// ستاره ها
var scorsId = [1,2,3,4,5,6,7,8,9,10];
scorsId.forEach(starId =>{
Score(starId);
});
function Score(starId) {
  const stars = document.querySelectorAll('.star-' + starId);
  const current_rating = document.querySelector('.current-rating-' + starId);

  stars.forEach((star, index) => {
    star.addEventListener('click', () => {

      let current_star = index + 1;
      current_rating.innerText = `${current_star} از 5`;

      stars.forEach((star, i) => {
        if (current_star >= i + 1) {
          star.innerHTML = '&#9733;';
        } else {
          star.innerHTML = '&#9734;';
        }
      });

    });
  });
}

// ستاره ها
// navBascket
var detailBascket = document.querySelector('.details-bascket');
flag = false;
var navbascket = document.querySelector('.nav-bascket').addEventListener('click', () => {
  if (flag == false) {
    detailBascket.classList.add('show');
    flag = true;
  }
  else {

    detailBascket.classList.remove('show');
    flag = false;
  }
});
//bascket Validate
function inventory() {

  if (detailBascket.childElementCount == 0) {
    detailBascket.innerHTML = '';
    detailBascket.innerHTML = '<div class="box-unavailable"><p>سبد خرید خالیست</p></div>';
  }
  else if (detailBascket.firstChild.innerText == '') {
    detailBascket.innerHTML = '';
    detailBascket.innerHTML = '<div class="box-unavailable"><p>سبد خرید خالیست</p></div>';
    var badge = document.querySelector('.badge');
    badge.innerText = 0;
  }
  else if (detailBascket.firstChild.innerText == 'سبد خرید خالیست') {
    if (detailBascket.childElementCount > 1) {
      detailBascket.firstChild.remove();
      detailBascket.innerHTML += '<div class="details-bascket-footer d-flex flex-column align-items-center"><p>مبلغ قابل پرداخت<span class="Payment-amount"><span id="Payment-amount">0</span>تومان</span></p><button class="btn btn-payment" onclick="ShowPayment()" data-bs-toggle="modal" data-bs-target="#staticBackdrop">پرداخت</button></div>';
    }
  }

  if (detailBascket.childElementCount > 1) {
    var boxBascket = document.querySelector('.box-bascket-item');
    var badge = document.querySelector('.badge');
    badge.textContent = boxBascket.childElementCount;
  }
}
inventory();
//bascket Validate
// btn Close
function closeBox(productId) {
  var bascketItem = document.querySelector('.bascket-item-' + productId);
  bascketItem.remove();
  var BtnAddToBascket = document.querySelector('.btn-addToBascket-' + productId);
  BtnAddToBascket.classList.remove('disabled');
  BtnAddToBascket.innerText = ' افزودن به سبد خرید';
  GetPaymentAmount();
}
// btn Close
// add to bascket
function AddToBascket(productId) {
  detailBascket.innerHTML += '<div class="box-bascket-item"></div>';
  var boxBascket = document.querySelector('.box-bascket-item');
  switch (productId) {
    case 1: {
      boxBascket.innerHTML += '<div class="bascket-item bascket-item-' + productId + ' mb-2"><div class="position-relative mb-2"><span class="fa fa-times _btn-close _btn-close-' + productId + '" onclick="closeBox(' + productId + ')" aria-hidden="true" style="position: absolute;left: 0;padding: 2px 4px;cursor: pointer;"></span></div><div class="d-flex align-items-center"><img src="img/img-1.png" class="bascket-img" width="60px" height="60px" alt=""><p class="bascket-text">شکلات اسنیکرز با مغز بادام زمینی</p> </div> <hr><div class="d-flex justify-content-between mb-2"><div class="d-flex flex-column text-center bascket-box-price total-price-' + productId + '"><span>قیمت کل</span><span><span class="total-price" id="totla-price-' + productId + '">0</span>تومان</span></div><div class="box-count"><div><button class="btn-increase-' + productId + ' bascket-btn" onclick="Increase(' + productId + ')">+</button><input type="number" min="1" value="1" class="bascket-count" onchange="GetTotalPrice(' + productId + ');GetPaymentAmount()" id="bascket-count-' + productId + '"><button class="btn-decrease-' + productId + ' bascket-btn" onclick="Decrease(' + productId + ')">-</button></div></div> <div class="d-flex flex-column text-center bascket-box-price price-product-' + productId + '"> <span>قیمت</span><span><span id="price-' + productId + '">60000</span>تومان</span></div></div></div>';
      inventory();
      break
    }
    case 2: {
      boxBascket.innerHTML += '<div class="bascket-item bascket-item-' + productId + ' mb-2"><div class="position-relative mb-2"><span class="fa fa-times _btn-close _btn-close-' + productId + '" onclick="closeBox(' + productId + ')" aria-hidden="true" style="position: absolute;left: 0;padding: 2px 4px;cursor: pointer;"></span></div><div class="d-flex align-items-center"><img src="img/img-2.png" class="bascket-img" width="60px" height="60px" alt=""><p class="bascket-text">شکلات تلخ 96 درصد</p> </div> <hr><div class="d-flex justify-content-between mb-2"><div class="d-flex flex-column text-center bascket-box-price total-price-' + productId + '"><span>قیمت کل</span><span><span class="total-price" id="totla-price-' + productId + '">0</span>تومان</span></div><div class="box-count"><div><button class="btn-increase-' + productId + ' bascket-btn" onclick="Increase(' + productId + ')">+</button><input type="number" min="1" value="1" class="bascket-count" onchange="GetTotalPrice(' + productId + ');GetPaymentAmount()" id="bascket-count-' + productId + '"><button class="btn-decrease-' + productId + ' bascket-btn" onclick="Decrease(' + productId + ')">-</button></div></div> <div class="d-flex flex-column text-center bascket-box-price price-product-' + productId + '"> <span>قیمت</span><span><span id="price-' + productId + '">4000</span>تومان</span></div></div></div>';
      inventory();
      break
    }
    case 3: {
      boxBascket.innerHTML += '<div class="bascket-item bascket-item-' + productId + ' mb-2"><div class="position-relative mb-2"><span class="fa fa-times _btn-close _btn-close-' + productId + '" onclick="closeBox(' + productId + ')" aria-hidden="true" style="position: absolute;left: 0;padding: 2px 4px;cursor: pointer;"></span></div><div class="d-flex align-items-center"><img src="img/img-3.png" class="bascket-img" width="60px" height="60px" alt=""><p class="bascket-text">شکلات مغزدار فندقی</p> </div> <hr><div class="d-flex justify-content-between mb-2"><div class="d-flex flex-column text-center bascket-box-price total-price-' + productId + '"><span>قیمت کل</span><span><span class="total-price" id="totla-price-' + productId + '">0</span>تومان</span></div><div class="box-count"><div><button class="btn-increase-' + productId + ' bascket-btn" onclick="Increase(' + productId + ')">+</button><input type="number" min="1" value="1" class="bascket-count" onchange="GetTotalPrice(' + productId + ');GetPaymentAmount()" id="bascket-count-' + productId + '"><button class="btn-decrease-' + productId + ' bascket-btn" onclick="Decrease(' + productId + ')">-</button></div></div> <div class="d-flex flex-column text-center bascket-box-price price-product-' + productId + '"> <span>قیمت</span><span><span id="price-' + productId + '">20000</span>تومان</span></div></div></div>';
      inventory();
      break
    }
    case 4: {
      boxBascket.innerHTML += '<div class="bascket-item bascket-item-' + productId + ' mb-2"><div class="position-relative mb-2"><span class="fa fa-times _btn-close _btn-close-' + productId + '" onclick="closeBox(' + productId + ')" aria-hidden="true" style="position: absolute;left: 0;padding: 2px 4px;cursor: pointer;"></span></div><div class="d-flex align-items-center"><img src="img/img-4.png" class="bascket-img" width="60px" height="60px" alt=""><p class="bascket-text">شکلات کاکائویی سکه ای</p> </div> <hr><div class="d-flex justify-content-between mb-2"><div class="d-flex flex-column text-center bascket-box-price total-price-' + productId + '"><span>قیمت کل</span><span><span class="total-price" id="totla-price-' + productId + '">0</span>تومان</span></div><div class="box-count"><div><button class="btn-increase-' + productId + ' bascket-btn" onclick="Increase(' + productId + ')">+</button><input type="number" min="1" value="1" class="bascket-count" onchange="GetTotalPrice(' + productId + ');GetPaymentAmount()" id="bascket-count-' + productId + '"><button class="btn-decrease-' + productId + ' bascket-btn" onclick="Decrease(' + productId + ')">-</button></div></div> <div class="d-flex flex-column text-center bascket-box-price price-product-' + productId + '"> <span>قیمت</span><span><span id="price-' + productId + '">8000</span>تومان</span></div></div></div>';
      inventory();
      break
    }
    case 5: {
      boxBascket.innerHTML += '<div class="bascket-item bascket-item-' + productId + ' mb-2"><div class="position-relative mb-2"><span class="fa fa-times _btn-close _btn-close-' + productId + '" onclick="closeBox(' + productId + ')" aria-hidden="true" style="position: absolute;left: 0;padding: 2px 4px;cursor: pointer;"></span></div><div class="d-flex align-items-center"><img src="img/img-5.png" class="bascket-img" width="60px" height="60px" alt=""><p class="bascket-text">شکلات اسنیکرز</p> </div> <hr><div class="d-flex justify-content-between mb-2"><div class="d-flex flex-column text-center bascket-box-price total-price-' + productId + '"><span>قیمت کل</span><span><span class="total-price" id="totla-price-' + productId + '">0</span>تومان</span></div><div class="box-count"><div><button class="btn-increase-' + productId + ' bascket-btn" onclick="Increase(' + productId + ')">+</button><input type="number" min="1" value="1" class="bascket-count" onchange="GetTotalPrice(' + productId + ');GetPaymentAmount()" id="bascket-count-' + productId + '"><button class="btn-decrease-' + productId + ' bascket-btn" onclick="Decrease(' + productId + ')">-</button></div></div> <div class="d-flex flex-column text-center bascket-box-price price-product-' + productId + '"> <span>قیمت</span><span><span id="price-' + productId + '">900</span>تومان</span></div></div></div>';
      inventory();
      break
    }
    case 6: {
      boxBascket.innerHTML += '<div class="bascket-item bascket-item-' + productId + ' mb-2"><div class="position-relative mb-2"><span class="fa fa-times _btn-close _btn-close-' + productId + '" onclick="closeBox(' + productId + ')" aria-hidden="true" style="position: absolute;left: 0;padding: 2px 4px;cursor: pointer;"></span></div><div class="d-flex align-items-center"><img src="img/img-6.png" class="bascket-img" width="60px" height="60px" alt=""><p class="bascket-text">شکلات هوبی</p> </div> <hr><div class="d-flex justify-content-between mb-2"><div class="d-flex flex-column text-center bascket-box-price total-price-' + productId + '"><span>قیمت کل</span><span><span class="total-price" id="totla-price-' + productId + '">0</span>تومان</span></div><div class="box-count"><div><button class="btn-increase-' + productId + ' bascket-btn" onclick="Increase(' + productId + ')">+</button><input type="number" min="1" value="1" class="bascket-count" onchange="GetTotalPrice(' + productId + ');GetPaymentAmount()" id="bascket-count-' + productId + '"><button class="btn-decrease-' + productId + ' bascket-btn" onclick="Decrease(' + productId + ')">-</button></div></div> <div class="d-flex flex-column text-center bascket-box-price price-product-' + productId + '"> <span>قیمت</span><span><span id="price-' + productId + '">66000</span>تومان</span></div></div></div>';
      inventory();
      break
    }
    case 7: {
      boxBascket.innerHTML += '<div class="bascket-item bascket-item-' + productId + ' mb-2"><div class="position-relative mb-2"><span class="fa fa-times _btn-close _btn-close-' + productId + '" onclick="closeBox(' + productId + ')" aria-hidden="true" style="position: absolute;left: 0;padding: 2px 4px;cursor: pointer;"></span></div><div class="d-flex align-items-center"><img src="img/img-7.png" class="bascket-img" width="60px" height="60px" alt=""><p class="bascket-text">شکلات تلخ 60 درصد</p> </div> <hr><div class="d-flex justify-content-between mb-2"><div class="d-flex flex-column text-center bascket-box-price total-price-' + productId + '"><span>قیمت کل</span><span><span class="total-price" id="totla-price-' + productId + '">0</span>تومان</span></div><div class="box-count"><div><button class="btn-increase-' + productId + ' bascket-btn" onclick="Increase(' + productId + ')">+</button><input type="number" min="1" value="1" class="bascket-count" onchange="GetTotalPrice(' + productId + ');GetPaymentAmount()" id="bascket-count-' + productId + '"><button class="btn-decrease-' + productId + ' bascket-btn" onclick="Decrease(' + productId + ')">-</button></div></div> <div class="d-flex flex-column text-center bascket-box-price price-product-' + productId + '"> <span>قیمت</span><span><span id="price-' + productId + '">26250</span>تومان</span></div></div></div>';
      inventory();
      break
    }
    case 8: {
      boxBascket.innerHTML += '<div class="bascket-item bascket-item-' + productId + ' mb-2"><div class="position-relative mb-2"><span class="fa fa-times _btn-close _btn-close-' + productId + '" onclick="closeBox(' + productId + ')" aria-hidden="true" style="position: absolute;left: 0;padding: 2px 4px;cursor: pointer;"></span></div><div class="d-flex align-items-center"><img src="img/img-8.png" class="bascket-img" width="60px" height="60px" alt=""><p class="bascket-text">شکلات لاویوا اولکر</p> </div> <hr><div class="d-flex justify-content-between mb-2"><div class="d-flex flex-column text-center bascket-box-price total-price-' + productId + '"><span>قیمت کل</span><span><span class="total-price" id="totla-price-' + productId + '">0</span>تومان</span></div><div class="box-count"><div><button class="btn-increase-' + productId + ' bascket-btn" onclick="Increase(' + productId + ')">+</button><input type="number" min="1" value="1" class="bascket-count" onchange="GetTotalPrice(' + productId + ');GetPaymentAmount()" id="bascket-count-' + productId + '"><button class="btn-decrease-' + productId + ' bascket-btn" onclick="Decrease(' + productId + ')">-</button></div></div> <div class="d-flex flex-column text-center bascket-box-price price-product-' + productId + '"> <span>قیمت</span><span><span id="price-' + productId + '">40000</span>تومان</span></div></div></div>';
      inventory();
      break
    }
    case 9: {
      boxBascket.innerHTML += '<div class="bascket-item bascket-item-' + productId + ' mb-2"><div class="position-relative mb-2"><span class="fa fa-times _btn-close _btn-close-' + productId + '" onclick="closeBox(' + productId + ')" aria-hidden="true" style="position: absolute;left: 0;padding: 2px 4px;cursor: pointer;"></span></div><div class="d-flex align-items-center"><img src="img/img-9.png" class="bascket-img" width="60px" height="60px" alt=""><p class="bascket-text">شکلات اسنیکرز با مغز بادام زمینی</p> </div> <hr><div class="d-flex justify-content-between mb-2"><div class="d-flex flex-column text-center bascket-box-price total-price-' + productId + '"><span>قیمت کل</span><span><span class="total-price" id="totla-price-' + productId + '">0</span>تومان</span></div><div class="box-count"><div><button class="btn-increase-' + productId + ' bascket-btn" onclick="Increase(' + productId + ')">+</button><input type="number" min="1" value="1" class="bascket-count" onchange="GetTotalPrice(' + productId + ');GetPaymentAmount()" id="bascket-count-' + productId + '"><button class="btn-decrease-' + productId + ' bascket-btn" onclick="Decrease(' + productId + ')">-</button></div></div> <div class="d-flex flex-column text-center bascket-box-price price-product-' + productId + '"> <span>قیمت</span><span><span id="price-' + productId + '">80000</span>تومان</span></div></div></div>';
      inventory();
      break
    }
    case 10: {
      boxBascket.innerHTML += '<div class="bascket-item bascket-item-' + productId + ' mb-2"><div class="position-relative mb-2"><span class="fa fa-times _btn-close _btn-close-' + productId + '" onclick="closeBox(' + productId + ')" aria-hidden="true" style="position: absolute;left: 0;padding: 2px 4px;cursor: pointer;"></span></div><div class="d-flex align-items-center"><img src="img/img-10.png" class="bascket-img" width="60px" height="60px" alt=""><p class="bascket-text">شکلات تلخ 40 درصد</p> </div> <hr><div class="d-flex justify-content-between mb-2"><div class="d-flex flex-column text-center bascket-box-price total-price-' + productId + '"><span>قیمت کل</span><span><span class="total-price" id="totla-price-' + productId + '">0</span>تومان</span></div><div class="box-count"><div><button class="btn-increase-' + productId + ' bascket-btn" onclick="Increase(' + productId + ')">+</button><input type="number" min="1" value="1" class="bascket-count" onchange="GetTotalPrice(' + productId + ');GetPaymentAmount()" id="bascket-count-' + productId + '"><button class="btn-decrease-' + productId + ' bascket-btn" onclick="Decrease(' + productId + ')">-</button></div></div> <div class="d-flex flex-column text-center bascket-box-price price-product-' + productId + '"> <span>قیمت</span><span><span id="price-' + productId + '">55000</span>تومان</span></div></div></div>';
      inventory();
      break
    }
  }
  var BtnAddToBascket = document.querySelector('.btn-addToBascket-' + productId);
  BtnAddToBascket.classList.add('disabled');
  BtnAddToBascket.innerText = 'اضافه شده به سبد خرید';

  GetTotalPrice(productId);
  GetPaymentAmount();
  // }
}
// add to bascket
// Increase
function Increase(productId) {
  var Inputcount = document.querySelector('#bascket-count-' + productId).value;
  if (Inputcount == 1) {
    document.querySelector('.btn-decrease-' + productId).removeAttribute('disabled', '');
  }
  document.querySelector('#bascket-count-' + productId).value++;
  GetTotalPrice(productId);
  GetPaymentAmount();
}
// Increase
// Decrease
function Decrease(productId) {
  var Inputcount = document.querySelector('#bascket-count-' + productId).value;
  if (Inputcount == 1) {
    document.querySelector('.btn-decrease-' + productId).setAttribute('disabled', '');
  }
  else {
    document.querySelector('#bascket-count-' + productId).value--;
    GetTotalPrice(productId);
    GetPaymentAmount();
  }
}
// Decrease
// Get Total Price
function GetTotalPrice(productId) {
  var count = document.querySelector('#bascket-count-' + productId).value;
  var price = parseFloat(document.querySelector('#price-' + productId).textContent);
  var totalPrice = count * price;
  document.querySelector('#totla-price-' + productId).textContent = totalPrice;
}
// Get Total Price
//Get Payment amount
function GetPaymentAmount() {
  var totalPrice = 0;
  document.querySelectorAll('.total-price').forEach((paragraph) => {
    totalPrice += parseFloat(paragraph.innerText);
  })
  document.querySelector('#Payment-amount').innerText = totalPrice;
}
//Get Payment amount
//payment
function ShowPayment() {
  var price = document.querySelector('#Payment-amount').innerText;
  document.querySelector('.pay-price').innerText = price;
}
function payment() {
  document.querySelector('.box-bascket-item').innerHTML = '';
  inventory();
  document.querySelectorAll('.btn-addToBascket').forEach(element => {
    element.classList.remove('disabled');
  });
  swal("پیغام", "پرداخت با موفقیت انجام شد", "success", {
    button: "بستن",
  });
}
//payment
// Available
function Available() {
  var radio1 = document.querySelector('#Radio-1');
  var radio2 = document.querySelector('#Radio-2');

  if (document.querySelector('#Available').checked) {
    document.querySelectorAll('.unavailable').forEach((element, index) => {
      element.style.display = "none";
    });
  }
  else {
    if (document.querySelector('#Discount').checked) {
      document.querySelectorAll('.unavailable').forEach((element) => {
        element.style.display = "block";
      });
      Discount();
    }
    else if (radio1.checked || radio2.checked) {
      document.querySelectorAll('.unavailable').forEach((element) => {
        element.style.display = "block";
      });
      PriceFilter();
    }
    else {
      document.querySelectorAll('.unavailable').forEach((element) => {
        element.style.display = "block";
      });
    }

  }
}
// Available
// Discount
function Discount() {
  if (document.querySelector('#Discount').checked) {
    document.querySelectorAll('.No-discount').forEach(element => {
      element.style.display = "none";
    });
  }
  else {
    if (document.querySelector('#Available').checked) {
      document.querySelectorAll('.No-discount').forEach(element => {
        element.style.display = "block";
      });
      Available();
    }
    else if (radio1.checked || radio2.checked) {
      document.querySelectorAll('.No-discount').forEach(element => {
        element.style.display = "block";
      });
      PriceFilter();
    }
    else {
      document.querySelectorAll('.No-discount').forEach(element => {
        element.style.display = "block";
      });
    }
  }
}
// Discount
//validate Email
function validateEmail(elementValue) {
  var emailPattern = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/;
  return emailPattern.test(elementValue);
}
//validate Email
function validate(email) {
  var valid = validateEmail(email);
  if (!valid) {
    document.querySelector('#email').style.color = 'red';
  } else {
    document.querySelector('#email').style.color = '#2bb673';
  }
}
//Send Email
function emailSend() {
  if (document.querySelector('#email').value == '') {
    document.querySelector('#email').focus();
  }
  else {
    var valid = validateEmail(document.querySelector('#email').value);
    if (!valid) {
      document.querySelector('#email').focus();
    } else {
      swal("پیغام", "ایمیل شما با موفقیت ثبت شد", "success", {
        button: "بستن",
      });
      document.querySelector('#email').value = '';
    }

  }

}
// price filter
var radio1 = document.querySelector('#Radio-1');
var radio2 = document.querySelector('#Radio-2');
function PriceFilter() {
  if (radio1.checked) {
    document.querySelectorAll('.card').forEach(element => {
      element.style.display = "none";
    });
    document.querySelectorAll('.price-1').forEach(element => {
      element.style.display = "block";
    });
  }
  else if (radio2.checked) {
    document.querySelectorAll('.card').forEach(element => {
      element.style.display = "none";
    });
    document.querySelectorAll('.price-2').forEach(element => {
      element.style.display = "block";
    });
  }
  else {
    if (document.querySelector('#Discount').checked) {

    }
    document.querySelectorAll('.card').forEach(element => {
      element.style.display = "block";
    });
  }
}
// price filter
// Clear Filter
function ClearFilter() {
  document.querySelectorAll('.radio-filter').forEach(element => {
    element.checked = false;
  })
  document.querySelectorAll('input[type="checkbox"]').forEach(element => {
    element.checked = false;
  })
  document.querySelectorAll('.card').forEach(element => {
    element.style.display = 'block';
  });

}
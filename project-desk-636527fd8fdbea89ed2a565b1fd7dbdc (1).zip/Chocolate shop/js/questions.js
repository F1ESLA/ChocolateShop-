// Supporter 
var boxSupporter = document.querySelector('.supporter-box');
setTimeout(function () {
    boxSupporter.style.right = '2%';

}, 5000);

var btnClose = document.querySelector('.btn-close').addEventListener('click', () => {
    boxSupporter.style.right = '-100%';
});
// Supporter 
// Chenge Header With Scroll
const nav = document.querySelector('.qu-nav');
document.addEventListener('scroll', () => {
    if (window.scrollY >= 410) {
        nav.classList.add('navbar-dark', 'bg-dark');
    }
    else {
        nav.classList.remove('navbar-dark', 'bg-dark');
    }
});
// End Chenge Header With Scroll
// validation
function sendInformation() {
    var _name = document.querySelector('.name');
    var _phone = document.querySelector('.phone');
    var valid_name_length = document.querySelector('#valid-name-length');
    var valid_phone = document.querySelector('#valid-phone');
    var Validation = false;
    if(Validation == false){
        if(_name.value.length < 5){
            valid_name_length.style.display = 'block';
            Validation = false;
        }
        else{
            valid_name_length.style.display = 'none';
            Validation = true;
        }
        if (_phone.value.length < 11) {
            valid_phone.style.display = 'block';
            Validation = false;
        }
        else {
            valid_phone.style.display = 'none';
            Validation = true;         
        }
    }

    if(Validation == true){
        _name.value = '';
        _phone.value = '';
        Validation = false;         
        HideBoxSupporter()
        swal("پیغام", "اطلاعات شما با موفقیت ثبت شد در کوتاه ترین زمان پاسخگوی شما خواهیم بود", "success", {
          button: "بستن",
        });
    }  
}
// hide box
function HideBoxSupporter(){
    setTimeout(function () {
        boxSupporter.style.right = '-100%'; 
    }, 2000);
}
// hide box
// validation
//validate Email
function validateEmail(elementValue) {
    var emailPattern = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/;
    return emailPattern.test(elementValue);
  }
  //validate Email
  function validate(email) {
    var valid = validateEmail(email);
    if (!valid) {
      document.querySelector('#email').style.color = 'red';
    } else {
      document.querySelector('#email').style.color = '#2bb673';
    }
  }
  // Send Email
  function emailSend() {
    if (document.querySelector('#email').value == '') {
      document.querySelector('#email').focus();
    }
    else {
      var valid = validateEmail(document.querySelector('#email').value);
      if (!valid) {
        document.querySelector('#email').focus();
      } else {
        document.querySelector('#email').value = '';
        swal("پیغام", "ایمیل با موفقیت ثبت شد", "success", {
          button: "بستن",
        });
      }
  
    }
  
  }
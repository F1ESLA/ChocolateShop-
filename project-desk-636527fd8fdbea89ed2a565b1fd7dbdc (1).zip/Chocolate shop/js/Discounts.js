// titmer
var times= ['#Discount-timer-1','#Discount-timer-2','#Discount-timer-3','#Discount-timer-4'];
times.forEach(element => {
    var x = setInterval(function(){
        var valTimer = document.querySelector(element).textContent;
        var hours = valTimer.split(':')[0];
        var minutes = valTimer.split(':')[1];
        var seconds = valTimer.split(':')[2];
        if(hours == 0 && minutes == 0 && seconds == 0){
            document.querySelector(element).textContent = 'پایان تخفیف';
            clearInterval(x);        
        }
        else{
            if(seconds == 0){
                if(minutes == 0 ){
                    hours--;
                    minutes=59;
                    seconds=60;
                }
                else{
                    minutes--;
                    seconds=60;
                }
            }
            seconds--;
            document.querySelector(element).textContent=hours+':'+minutes+':'+seconds;
        }    
    },1000);
    });   
// titmer